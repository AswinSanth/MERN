import './postdetail.css';
import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';

const PostDetail = () => {
  const { postid } = useParams();
  const [postData, setPostData] = useState({});
  const [commentData, setCommentData] = useState([]);
  const [userData, setUserData] = useState({});
  const fetchData = async () => {
    const res1 = await fetch(
      `https://jsonplaceholder.typicode.com/posts/${postid}`
    );
    const data1 = await res1.json();
    setPostData(data1);
    const res2 = await fetch(
      `https://jsonplaceholder.typicode.com/comments?postId=${postid}`
    );
    const data2 = await res2.json();
    setCommentData(data2);
    const res3 = await fetch(
      `https://jsonplaceholder.typicode.com/users/${data1.userId}`
    );
    const data3 = await res3.json();
    setUserData(data3);
  };
  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="postDetails">
      <h2>{postData.id}</h2>
      <h2>{userData.id}</h2>

      <div className="comments">
       { commentData.map(item=>{
        return(
        <div className="commentlist">
          <p>{item.id}</p>
          <p>{item.name}</p>
          <p>{item.email}</p>
          <p>{item.body}</p>

        </div>
        )
       })}
      </div>
    </div>
  );
};
export default PostDetail;
